var app = React.createElement(App);
ReactDOM.render(app, document.getElementById('app'));
