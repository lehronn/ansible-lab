# Giphy GIF Search App

GIF Search App with ReactJS and Giphy API.

## Commands

`npm install` to install dependencies

`npm start` to run development version on browser
