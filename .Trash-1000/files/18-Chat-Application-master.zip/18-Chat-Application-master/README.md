# Chat Aplication

Chat application with node.js, express.js, react.js and socket.io 

## Commands

`npm install` to install dependencies

`npm run build` to build distribution version, babel required.

## Running instructions

For running React Chat You have to:
* git clone this repo.
* Run `index.js` with `node index.js` command. You can use pm2 or smth like this.
* Run `localhost:3000` in browser. Public folder contains ready distribution version.
